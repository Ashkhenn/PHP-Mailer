<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = test_input($_POST["email"]);
    $message = test_input($_POST["message"]);

    if (empty($email) || empty($message)) {
        die("Пожалуйста, заполните все поля.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Неверный формат email.");
    }

    $to = "ashkhenharutyunyan.000@gmail.com";
    $subject = "Новое сообщение от $email";
    $headers = "From: $to";

    if (mail($to, $subject, $message, $headers)) {
        echo "Сообщение отправлено успешно!";
    } else {
        die("Ошибка при отправке сообщения.");
    }
} else {
    die("Ошибка: Недопустимый запрос");
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>