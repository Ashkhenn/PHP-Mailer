<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Name from db</title>
    <style>
        button{
            width: 200px;
            height: 50px;
            background-color: green;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            color: white;
            font-size: 25px;
            margin:200px 800px;
        }
    </style>
</head>
<body>
    <button id="btn">Get Info</button>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="js/js.js"></script>
</html>