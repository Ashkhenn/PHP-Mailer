<?php

session_start();
class Model{
    private $db;
    public function __construct(){
        $this->db = new mysqli('localhost', 'root', '', 'firstTz');
        if($_POST['action']){
            call_user_func([$this, $_POST['action']]);
        }
    }
    public function getInfo(){
        $userId = [];
        $userName = [];
        $groupId = [];

        foreach( ($this->db->query('SELECT * FROM `Users` WHERE `groups` = 1')->fetch_all(true) ) as $value){
            array_push($userId, $value['id']);
            array_push($userName, $value['name']);
        }

        foreach($this->db->query('SELECT `name` FROM `Groups` WHERE `id` = 1')->fetch_all(true) as $value){
            array_push($groupId,$value['name']);
        }
        // $groupName = [];
        // for($i = 0; $i < count($groupId); $i++){
        //     // array_push($groupName, $this->db->query('SELECT name FROM Groups WHERE id = "$groupId[$i]"')->fetch_all(true));
        //     $this->db->query('SELECT name FROM Groups WHERE id = "$groupId[$i]"')->fetch_all(true);
        // }
        // var_dump("$groupName");
        $_SESSION['UserId']=$userId;
        $_SESSION['UserName']=$userName;
        $_SESSION['GroupId']=$groupId;
        $_SESSION['GroupName']=$groupName;
        var_dump($_SESSION);
    }
}

$obj = new Model;


?>