let btn = document.getElementById("btn");
btn.addEventListener("click", function(){
    $.ajax({
        url:'server.php',
        method:'POST',
        dataType:'html',
        data:{action:'getInfo'},
        success:function(r){
            // console.log(r);
            window.location.href="index1.php";
        }
    })
})