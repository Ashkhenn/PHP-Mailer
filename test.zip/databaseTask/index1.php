<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Name Page</title>
</head>
<body>
    <table border="1"  cellspacing="0" width="50%" height="200px" align="center">
        <tr align="center">
            <td>Id</td>
            <td>Name</td>
            <td>GroupName</td>
        </tr>
         <?php for($i = 0; $i < count($_SESSION["UserId"]); $i++ ){  ?>
        <tr align="center">
            <td><?=$_SESSION["UserId"][$i]?></td>
            <td><?=$_SESSION["UserName"][$i]?></td>
            <td><?=$_SESSION["GroupId"][$i]?></td>
        </tr>
           <?php  } ?>     
    </table>
</body>
</html>